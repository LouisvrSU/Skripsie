int Led1Pin = 25;   // BLUE
int Led2Pin = 26;   // RED
int Led3Pin = 13;   // GREEN

int scanner_rx=14;
int scanner_tx=27;